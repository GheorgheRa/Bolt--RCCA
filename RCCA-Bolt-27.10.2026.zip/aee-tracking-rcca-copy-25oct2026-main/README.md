# Aeronamic RCCA Tracker

A standalone production issue, corrective-action, batch-monitoring, document, analytics, visual-inspection, and daily-standup application. The React interface is served by Vite during development and by the Node.js server in production. Application data is stored in SQLite; uploaded files are stored on the server.

## Requirements

- Node.js 22.13 or newer
- npm

## Run locally

1. Install the frontend dependencies with `npm install`.
2. Copy `.env.example` to `.env` and set a strong `ADMIN_PASSWORD` and the administrator's `ADMIN_EMAIL`. `ADMIN_NAME` is optional.
3. Start the application with `npm run dev`.
4. Open the URL printed by Vite. The server creates the first administrator on startup when the database is empty.

For a first-time installation without environment credentials, open the app and use **Set up this installation** to create the first administrator. The one-time setup endpoint closes as soon as that account is created.

The default data directory is `./data` (SQLite database and uploads). Set `DATA_DIR` to move it outside the repository. Keep this directory backed up; it is intentionally excluded from Git.

## Production

Run `npm run build`, then `npm start`. The Node.js server serves both the API and the built frontend on port `3001` by default. Set `PORT` to change it. Terminate TLS at a reverse proxy and set `COOKIE_SECURE=true` when serving over HTTPS.

## Configuration

| Variable | Purpose |
| --- | --- |
| `PORT` | HTTP port (default `3001`) |
| `DATA_DIR` | Directory for SQLite and uploaded files (default `./data`) |
| `ADMIN_EMAIL` / `ADMIN_PASSWORD` | Optional first-administrator bootstrap; set both or neither |
| `ADMIN_NAME` | Optional name for the bootstrapped administrator |
| `COOKIE_SECURE` | Set to `true` when HTTPS is terminated in front of the server |
| `AI_API_KEY` | Optional API key for an OpenAI-compatible AI provider |
| `AI_BASE_URL` | Optional provider base URL (default `https://api.openai.com/v1`) |
| `AI_MODEL` | Optional model name supported by that provider |
| `RESEND_API_KEY` / `EMAIL_FROM` | Optional Resend email delivery configuration |
| `CRITICAL_ALERT_TO` | Optional recipient for newly created critical-issue alerts |

AI analysis and email delivery require their respective provider configuration. The rest of the application works without those integrations. Scheduled corrective-action and standup reminders run daily at 05:00 UTC when email delivery is configured.

Administrators can create accounts and manage page access from **Settings**. Passwords must be at least 12 characters; each user can change their password in Settings.

This is a fresh standalone data store; records and uploaded files from the previous hosted service are not imported. Before production use, add the site-specific part-number/alias and machine-serial picklists from **Settings**.

## Validation

- `npm test` runs the backend tests.
- `npm run lint` checks the repository.
- `npm run typecheck` checks the JavaScript project.
- `npm run build` creates the production frontend.
