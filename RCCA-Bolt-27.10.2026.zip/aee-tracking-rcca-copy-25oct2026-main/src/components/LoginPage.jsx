import React, { useEffect, useState } from 'react';
import { AlertTriangle, Loader2, ShieldCheck } from 'lucide-react';
import { useAuth } from '@/lib/AuthContext';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

export default function LoginPage() {
  const { login, bootstrap, error: authError } = useAuth();
  const [hasUsers, setHasUsers] = useState(true);
  const [checking, setChecking] = useState(true);
  const [creating, setCreating] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [form, setForm] = useState({ email: '', full_name: '', password: '' });

  useEffect(() => {
    fetch('/api/status')
      .then(response => {
        if (!response.ok) throw new Error('Could not reach the server.');
        return response.json();
      })
      .then(status => setHasUsers(status.hasUsers))
      .catch(err => setError(err.message))
      .finally(() => setChecking(false));
  }, []);

  const submit = async event => {
    event.preventDefault();
    setSubmitting(true);
    setError('');
    try {
      if (creating && !hasUsers) {
        await bootstrap(form);
      } else {
        await login({ email: form.email, password: form.password });
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  if (checking) {
    return <div className="fixed inset-0 flex items-center justify-center bg-slate-50"><Loader2 className="h-6 w-6 animate-spin text-blue-600" /></div>;
  }

  const showBootstrap = !hasUsers && creating;
  return (
    <main className="min-h-screen flex items-center justify-center bg-slate-50 px-4 py-10">
      <section className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-7 shadow-sm">
        <div className="mb-7 flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-blue-600 text-white">
            {showBootstrap ? <ShieldCheck className="h-5 w-5" /> : <AlertTriangle className="h-5 w-5" />}
          </div>
          <div>
            <p className="font-bold text-slate-900">Aeronamic Sibiu</p>
            <p className="text-sm text-slate-500">RCCA Tracker</p>
          </div>
        </div>
        <h1 className="text-xl font-bold text-slate-900">
          {showBootstrap ? 'Create the administrator' : 'Sign in'}
        </h1>
        <p className="mt-1 text-sm text-slate-500">
          {showBootstrap ? 'Set up the first account for this installation.' : 'Use your work account to continue.'}
        </p>
        {(error || authError?.message) && (
          <p role="alert" className="mt-4 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">
            {error || authError.message}
          </p>
        )}
        <form onSubmit={submit} className="mt-5 space-y-4">
          {showBootstrap && (
            <label className="block text-sm font-medium text-slate-700">
              Full name
              <Input required autoComplete="name" className="mt-1" value={form.full_name} onChange={event => setForm({ ...form, full_name: event.target.value })} />
            </label>
          )}
          <label className="block text-sm font-medium text-slate-700">
            Email
            <Input required type="email" autoComplete="username" className="mt-1" value={form.email} onChange={event => setForm({ ...form, email: event.target.value })} />
          </label>
          <label className="block text-sm font-medium text-slate-700">
            Password
            <Input required type="password" minLength={showBootstrap ? 12 : 1} autoComplete={showBootstrap ? 'new-password' : 'current-password'} className="mt-1" value={form.password} onChange={event => setForm({ ...form, password: event.target.value })} />
            {showBootstrap && <span className="mt-1 block text-xs font-normal text-slate-500">Use at least 12 characters.</span>}
          </label>
          <Button type="submit" className="w-full" disabled={submitting}>
            {submitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {showBootstrap ? 'Create administrator' : 'Sign in'}
          </Button>
        </form>
        {!hasUsers && (
          <button
            type="button"
            className="mt-4 w-full text-center text-sm text-blue-700 hover:underline"
            onClick={() => { setCreating(value => !value); setError(''); }}
          >
            {showBootstrap ? 'Back to sign in' : 'Set up this installation'}
          </button>
        )}
      </section>
    </main>
  );
}
