import React, { useRef, useState } from 'react';
import { appApi } from '@/api/appClient';
import { Button } from '@/components/ui/button';
import { Download, Upload, Loader2, UserPlus, KeyRound, X } from 'lucide-react';
import { IMPORT_ACCEPT, datedFileName, downloadCsv, downloadTable, readTableFile } from '@/components/shared/tableFiles';
import { MAX_IMPORT_USERS, USER_EXPORT_HEADERS, buildUserExportRows, isUserHeaderRow, rowsToNewUsers } from './usersFiles';

// The Settings list is capped by getUsers; export and duplicate checks need every account.
const fetchAllUsers = () => appApi.entities.User.list('email', 50000);

const STATUS_COLORS = { success: 'text-green-600', warning: 'text-amber-600', error: 'text-red-600' };

export default function UsersFileActions({ users, onImported }) {
  const fileInputRef = useRef(null);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState(null);
  const [pending, setPending] = useState(null);
  const [credentials, setCredentials] = useState(null);

  const handleExport = async (format) => {
    try {
      downloadTable(format, {
        title: 'Users',
        headers: USER_EXPORT_HEADERS,
        rows: buildUserExportRows(await fetchAllUsers()),
        filename: datedFileName('users'),
        sheetName: 'Users',
      });
    } catch (error) {
      setStatus({ type: 'error', text: `Export failed: ${error instanceof Error ? error.message : String(error)}` });
    }
  };

  const handleImport = async (event) => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    setBusy(true);
    setStatus(null);
    setPending(null);
    try {
      const [table, allUsers] = await Promise.all([readTableFile(file, isUserHeaderRow), fetchAllUsers()]);
      const result = rowsToNewUsers(table, allUsers);
      const details = [];
      if (result.duplicates) details.push(`${result.duplicates} already exist`);
      if (result.invalid) details.push(`${result.invalid} without a valid email`);
      if (result.unknownPages.length) details.push(`unknown pages ignored: ${result.unknownPages.join(', ')}`);
      if (!result.headerDetected) {
        setStatus({ type: 'error', text: 'No header row with an "Email" column was found in the file.' });
      } else if (result.toCreate.length > MAX_IMPORT_USERS) {
        setStatus({ type: 'error', text: `The file has ${result.toCreate.length} new users; the limit is ${MAX_IMPORT_USERS} per import.` });
      } else if (!result.toCreate.length) {
        setStatus({ type: 'warning', text: details.length ? `No new users to create (${details.join(', ')}).` : 'No users found in the file.' });
      } else {
        setPending({ users: result.toCreate, details });
      }
    } catch (error) {
      setStatus({ type: 'error', text: `Import failed: ${error instanceof Error ? error.message : String(error)}` });
    } finally {
      setBusy(false);
    }
  };

  const createPending = async () => {
    setBusy(true);
    const created = [];
    const failed = [];
    const profileFailed = [];
    /** @param {unknown} error */
    const message = error => (error instanceof Error ? error.message : String(error));
    for (const account of pending.users) {
      let user;
      try {
        user = await appApi.auth.createUser({
          email: account.email,
          full_name: account.full_name,
          password: account.password,
          role: account.role,
        });
      } catch (error) {
        failed.push(`${account.email}: ${message(error)}`);
        continue;
      }
      created.push(account);
      if (account.display_name || account.page_permissions) {
        try {
          await appApi.entities.User.update(user.id, {
            display_name: account.display_name,
            page_permissions: account.page_permissions,
          });
        } catch (error) {
          profileFailed.push(`${account.email}: ${message(error)}`);
        }
      }
    }
    const withGenerated = created.filter(account => account.generated);
    // Generated passwords exist only here, so keep any not yet downloaded from earlier imports.
    if (withGenerated.length) setCredentials(previous => [...(previous || []), ...withGenerated]);
    setPending(null);
    setBusy(false);
    let text = `Created ${created.length} account${created.length === 1 ? '' : 's'}.`;
    if (failed.length) text += ` Failed: ${failed.join('; ')}.`;
    if (profileFailed.length) text += ` Created, but display name/page access not saved: ${profileFailed.join('; ')}.`;
    const hasProblems = failed.length || profileFailed.length;
    setStatus({ type: hasProblems ? (created.length ? 'warning' : 'error') : 'success', text });
    onImported?.();
  };

  const downloadCredentials = () => {
    downloadCsv(
      ['Email', 'Full name', 'Temporary password'],
      credentials.map(account => [account.email, account.full_name, account.password]),
      datedFileName('temporary passwords'),
    );
  };

  return (
    <div className="mb-4 space-y-2 rounded-lg border border-slate-200 p-3">
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-xs text-slate-500">Export:</span>
        {[['pdf', 'PDF'], ['xlsx', 'Excel'], ['csv', 'CSV']].map(([format, label]) => (
          <Button key={format} size="sm" variant="outline" className="h-7 text-xs" onClick={() => handleExport(format)} disabled={!users.length}>
            <Download className="w-3.5 h-3.5" />
            {label}
          </Button>
        ))}
        <Button size="sm" variant="outline" className="h-7 text-xs ml-auto" onClick={() => fileInputRef.current?.click()} disabled={busy}>
          {busy ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Upload className="w-3.5 h-3.5" />}
          Import (PDF / Excel / CSV)
        </Button>
        <input ref={fileInputRef} type="file" accept={IMPORT_ACCEPT} className="hidden" onChange={handleImport} />
      </div>

      {pending && (
        <div className="space-y-2 rounded-md bg-blue-50 p-2">
          <p className="text-xs font-medium text-slate-700">
            {pending.users.length} new account{pending.users.length === 1 ? '' : 's'} will be created
            {pending.details.length ? ` (${pending.details.join(', ')})` : ''}:
          </p>
          <ul className="max-h-40 overflow-y-auto text-xs text-slate-600">
            {pending.users.map(account => (
              <li key={account.email}>
                {account.full_name} &lt;{account.email}&gt; — {account.role}
                {account.generated ? ' — temporary password will be generated' : ''}
              </li>
            ))}
          </ul>
          <div className="flex gap-2">
            <Button size="sm" className="h-7 text-xs" onClick={createPending} disabled={busy}>
              <UserPlus className="w-3.5 h-3.5" />
              Create accounts
            </Button>
            <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => setPending(null)} disabled={busy}>
              <X className="w-3.5 h-3.5" />
              Cancel
            </Button>
          </div>
        </div>
      )}

      {status && <p role="status" className={`text-xs ${STATUS_COLORS[status.type]}`}>{status.text}</p>}

      {credentials && (
        <div className="space-y-1.5 rounded-md bg-amber-50 p-2">
          <p className="text-xs text-amber-800">
            {credentials.length} account{credentials.length === 1 ? '' : 's'} received a generated temporary password. Download them now —
            they are not stored and cannot be shown again. Share them privately and ask users to change their password in Settings.
          </p>
          <div className="flex gap-2">
            <Button size="sm" variant="outline" className="h-7 text-xs" onClick={downloadCredentials}>
              <KeyRound className="w-3.5 h-3.5" />
              Download temporary passwords (CSV)
            </Button>
            <Button size="sm" variant="ghost" className="h-7 text-xs" onClick={() => setCredentials(null)}>
              Dismiss
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
