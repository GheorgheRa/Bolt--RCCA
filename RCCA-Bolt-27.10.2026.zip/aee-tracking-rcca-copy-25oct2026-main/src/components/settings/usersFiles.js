export const PAGE_PERMISSION_KEYS = [
  { key: 'Dashboard', label: 'Dashboard' },
  { key: 'Issues', label: 'Issues' },
  { key: 'BatchMonitor', label: 'Production Monitor' },
  { key: 'Analytics', label: 'Analytics' },
  { key: 'Documents', label: 'Documents' },
  { key: 'Archive', label: 'Archive' },
  { key: 'ProductionMeeting', label: 'Production Meeting' },
  { key: 'Settings', label: 'Settings' },
  { key: 'VisualInspection', label: 'Visual Inspection AI' },
];

export const USER_EXPORT_HEADERS = ['Full name', 'Display name', 'Email', 'Role', 'Page access', 'Created'];

export const MIN_PASSWORD_LENGTH = 12;
export const MAX_IMPORT_USERS = 200;

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/** @param {unknown} text */
const normalizeHeader = text => String(text ?? '').toLowerCase().replace(/\(optional\)/g, '').replace(/[^a-z0-9]/g, '');

/** @param {unknown} cell */
const cellText = cell => String(cell ?? '').replace(/\s+/g, ' ').trim();

const HEADER_ALIASES = {
  email: ['email', 'emailaddress', 'mail', 'adresaemail', 'adresademail'],
  full_name: ['fullname', 'name', 'nume', 'numecomplet', 'numesiprenume'],
  display_name: ['displayname', 'numeafisat', 'alias'],
  role: ['role', 'rol'],
  password: ['password', 'parola', 'temporarypassword', 'parolatemporara'],
  page_permissions: ['pageaccess', 'pagepermissions', 'permissions', 'pages', 'pagini', 'acces', 'drepturi'],
};

/** @param {string | null | undefined} raw */
export function parsePagePermissions(raw) {
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

// Mirrors hasAccess in Layout.jsx: admins see every page, other users without a permission map
// only see the default pages.
export const DEFAULT_PAGE_ACCESS = ['Dashboard', 'Issues'];

/**
 * @param {string | null | undefined} raw
 * @param {string} [role]
 */
export function formatPageAccess(raw, role = 'user') {
  if (role === 'admin') return 'All';
  const stored = parsePagePermissions(raw);
  const permissions = stored || Object.fromEntries(DEFAULT_PAGE_ACCESS.map(key => [key, true]));
  const granted = PAGE_PERMISSION_KEYS.filter(({ key }) => permissions[key]).map(({ label }) => label);
  return granted.length ? granted.join(', ') : 'None';
}

/**
 * Turns an empty cell into null (default access) and "All" / a list of page names into the stored
 * JSON map.
 * @param {string} text
 * @returns {{ value: string | null, unknown: string[] }}
 */
export function parsePageAccess(text) {
  const trimmed = text.trim();
  if (!trimmed) return { value: null, unknown: [] };
  const keyword = trimmed.toLowerCase();
  const wanted = ['all', 'toate'].includes(keyword)
    ? PAGE_PERMISSION_KEYS.map(({ key }) => normalizeHeader(key))
    : ['none', 'niciuna'].includes(keyword)
      ? []
      : trimmed.split(/[,;|]/).map(part => normalizeHeader(part)).filter(Boolean);
  /** @type {Record<string, boolean>} */
  const permissions = {};
  const matched = new Set();
  for (const { key, label } of PAGE_PERMISSION_KEYS) {
    const hit = wanted.find(name => name === normalizeHeader(key) || name === normalizeHeader(label));
    permissions[key] = Boolean(hit);
    if (hit) matched.add(hit);
  }
  return { value: JSON.stringify(permissions), unknown: wanted.filter(name => !matched.has(name)) };
}

/** @param {Array<Record<string, any>>} users */
export function buildUserExportRows(users) {
  return [...users]
    .sort((a, b) => String(a.email).localeCompare(String(b.email)))
    .map(user => [
      user.full_name || '',
      user.display_name || '',
      user.email || '',
      user.role || 'user',
      formatPageAccess(user.page_permissions, user.role),
      user.created_date ? String(user.created_date).slice(0, 10) : '',
    ]);
}

/**
 * @param {unknown[]} row
 * @returns {Record<string, number> | null}
 */
function detectColumns(row) {
  /** @type {Record<string, number>} */
  const columns = {};
  row.forEach((cell, index) => {
    const header = normalizeHeader(cell);
    for (const [field, aliases] of Object.entries(HEADER_ALIASES)) {
      if (!(field in columns) && aliases.includes(header)) {
        columns[field] = index;
        return;
      }
    }
  });
  return 'email' in columns ? columns : null;
}

/** @param {unknown[]} row */
export const isUserHeaderRow = row => detectColumns(row) !== null;

/** @param {number} [length] */
export function generatePassword(length = 16) {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
  const bytes = new Uint32Array(length);
  globalThis.crypto.getRandomValues(bytes);
  return Array.from(bytes, byte => alphabet[byte % alphabet.length]).join('');
}

/**
 * Converts a parsed table into new accounts. Requires a header row with an email column; other
 * columns (name, display name, role, password, page access) are optional. Rows whose email already
 * exists, or repeats within the file, are skipped. Missing or short passwords are replaced by a
 * generated temporary password.
 *
 * @param {unknown[][]} table
 * @param {Array<Record<string, any>>} existingUsers
 */
export function rowsToNewUsers(table, existingUsers) {
  const rows = table.filter(row => Array.isArray(row) && row.some(cell => cellText(cell)));
  let columns = null;
  let headerIndex = -1;
  for (let index = 0; index < Math.min(rows.length, 5); index += 1) {
    columns = detectColumns(rows[index]);
    if (columns) {
      headerIndex = index;
      break;
    }
  }
  if (!columns) return { toCreate: [], duplicates: 0, invalid: rows.length, generatedPasswords: 0, unknownPages: [], headerDetected: false };

  const seen = new Set(existingUsers.map(user => String(user.email ?? '').trim().toLowerCase()));
  const toCreate = [];
  const unknownPages = new Set();
  let duplicates = 0;
  let invalid = 0;
  let generatedPasswords = 0;

  for (const row of rows.slice(headerIndex + 1)) {
    /** @param {string} field */
    const get = field => (field in columns ? cellText(row[columns[field]]) : '');
    const email = get('email').toLowerCase();
    if (!EMAIL_PATTERN.test(email)) {
      invalid += 1;
      continue;
    }
    if (seen.has(email)) {
      duplicates += 1;
      continue;
    }
    seen.add(email);

    const displayName = get('display_name');
    let password = get('password');
    const generated = password.length < MIN_PASSWORD_LENGTH;
    if (generated) {
      password = generatePassword();
      generatedPasswords += 1;
    }
    const access = parsePageAccess(get('page_permissions'));
    access.unknown.forEach(name => unknownPages.add(name));
    toCreate.push({
      email,
      full_name: get('full_name') || displayName || email.split('@')[0],
      display_name: displayName || null,
      role: get('role').toLowerCase() === 'admin' ? 'admin' : 'user',
      page_permissions: access.value,
      password,
      generated,
    });
  }

  return { toCreate, duplicates, invalid, generatedPasswords, unknownPages: [...unknownPages], headerDetected: true };
}
