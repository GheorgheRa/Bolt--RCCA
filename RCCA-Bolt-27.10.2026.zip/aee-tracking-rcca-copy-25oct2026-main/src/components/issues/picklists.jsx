import { appApi } from '@/api/appClient';

const DEFAULT_OPTIONS = {
  IssueType_Picklist: [
    'Process efficiency',
    'Material (Supplier)',
    'FPI',
    'Handling',
    'TC human error',
    'Setup',
    'Tool & Fixture',
    'Special Process',
    'Deburring',
    'Machine defective',
    'Breakdown',
    'Measurement',
  ],
  ProcessStep_Picklist: [
    'Moriseiki',
    'Chiron',
    'Hermle',
    'Hembrug',
    'Benzinger',
    'Debavurare',
    'Marcare',
    'Inspectie Intermediara',
    'Procese Speciale',
    'FPI',
    'Brazare',
    'Asamblare',
    'Inspectie Finala',
  ],
  department: [
    'Productie',
    'Procese Speciale',
    'FPI',
    'CADCAM',
    'Quality',
    'LE',
    'Logistica',
    'Mentenanta',
    'Management',
  ],
  DefectType_Picklist: [
    'Dimensional',
    'Functional',
    'Vizual',
    'Acoperire',
    'Documentatie',
    'Trasabilitate',
    'Altele',
  ],
};

const cache = new Map();

async function fetchOptions(category) {
  if (cache.has(category)) return cache.get(category);
  const options = await appApi.entities.PicklistOption.filter(
    { category, is_active: true },
    'sort_order',
    500,
  );
  const result = options.length
    ? options
      .filter(option => option.value != null && option.value !== '')
      .map(option => ({ value: option.value, label: option.label }))
    : (DEFAULT_OPTIONS[category] || []).map(value => ({ value, label: value }));
  result.sort((a, b) => a.label.localeCompare(b.label));
  cache.set(category, result);
  return result;
}

export function fetchIssueTypes() {
  return fetchOptions('IssueType_Picklist');
}

export function fetchProcessSteps() {
  return fetchOptions('ProcessStep_Picklist');
}

export function fetchAssignDpt() {
  return fetchOptions('department');
}

export function fetchDefectTypes() {
  return fetchOptions('DefectType_Picklist');
}

export async function fetchPartNumberAlias() {
  if (cache.has('partNumberAlias')) return cache.get('partNumberAlias');
  const options = await appApi.entities.PicklistOption.filter(
    { category: 'Part Number vs Alias_Picklist', is_active: true },
    'sort_order',
    500,
  );
  const result = options
    .filter(option => option.value != null && option.value !== '')
    .map(option => ({ partNumber: option.value, alias: option.label }));
  cache.set('partNumberAlias', result);
  return result;
}

export async function fetchUtilajSerial() {
  if (cache.has('utilajSerial')) return cache.get('utilajSerial');
  const options = await appApi.entities.PicklistOption.filter(
    { category: 'Utilaj - Serial#_Picklist', is_active: true },
    'sort_order',
    500,
  );
  const result = options.map(option => ({ partNumber: option.value, alias: option.label }));
  cache.set('utilajSerial', result);
  return result;
}
