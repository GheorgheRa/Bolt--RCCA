import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { createServer } from 'node:net';
import { mkdtemp, rm } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { after, before, test } from 'node:test';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
let baseUrl;
let dataDirectory;
let temporaryRoot;
let serverProcess;
let adminCookie;
let userCookie;
let bootstrapStatus;
let bootstrappedUser;
let secondBootstrapStatus;
let createdOperator;
let userLoginStatus;

async function findAvailablePort() {
  const socket = createServer();
  await new Promise((resolve, reject) => socket.once('error', reject).listen(0, '127.0.0.1', resolve));
  const { port } = socket.address();
  await new Promise((resolve, reject) => socket.close(error => error ? reject(error) : resolve()));
  return port;
}

async function api(pathname, { cookie, ...options } = {}) {
  return fetch(`${baseUrl}${pathname}`, {
    ...options,
    headers: {
      'X-App-Request': 'true',
      ...(options.body ? { 'Content-Type': 'application/json' } : {}),
      ...(cookie ? { Cookie: cookie } : {}),
      ...options.headers,
    },
  });
}

async function waitForServer() {
  const deadline = Date.now() + 8000;
  while (Date.now() < deadline) {
    try {
      const response = await fetch(`${baseUrl}/api/status`);
      if (response.ok) return;
    } catch {
      await new Promise(resolve => setTimeout(resolve, 100));
    }
  }
  throw new Error('The API server did not start.');
}

before(async () => {
  temporaryRoot = await mkdtemp(path.join(os.tmpdir(), 'rcca-api-test-'));
  dataDirectory = path.join(temporaryRoot, 'nested', 'data');
  const port = await findAvailablePort();
  baseUrl = `http://127.0.0.1:${port}`;
  serverProcess = spawn(process.execPath, [
    '--disable-warning=ExperimentalWarning',
    'server/index.js',
  ], {
    cwd: root,
    env: { ...process.env, PORT: String(port), DATA_DIR: dataDirectory, COOKIE_SECURE: 'false', ADMIN_EMAIL: '', ADMIN_PASSWORD: '' },
    stdio: 'inherit',
  });
  await waitForServer();

  const bootstrap = await api('/api/auth/bootstrap', {
    method: 'POST',
    body: JSON.stringify({
      email: 'admin@example.test',
      full_name: 'Test Admin',
      password: 'test-admin-password-1',
    }),
  });
  bootstrapStatus = bootstrap.status;
  bootstrappedUser = await bootstrap.json();
  adminCookie = bootstrap.headers.get('set-cookie').split(';')[0];

  const secondBootstrap = await api('/api/auth/bootstrap', {
    method: 'POST',
    body: JSON.stringify({
      email: 'second@example.test',
      full_name: 'Second Admin',
      password: 'second-admin-password',
    }),
  });
  secondBootstrapStatus = secondBootstrap.status;

  const created = await api('/api/auth/users', {
    method: 'POST',
    cookie: adminCookie,
    body: JSON.stringify({
      email: 'operator@example.test',
      full_name: 'Line Operator',
      password: 'operator-password-12',
    }),
  });
  createdOperator = await created.json();
  const login = await api('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email: 'operator@example.test', password: 'operator-password-12' }),
  });
  userLoginStatus = login.status;
  userCookie = login.headers.get('set-cookie').split(';')[0];
});

after(async () => {
  if (serverProcess && serverProcess.exitCode === null) {
    serverProcess.kill('SIGTERM');
    await new Promise(resolve => serverProcess.once('exit', resolve));
  }
  if (temporaryRoot) await rm(temporaryRoot, { recursive: true, force: true });
});

test('first-run bootstrap creates an administrator and a secure session', async () => {
  assert.equal(bootstrapStatus, 201);
  assert.equal(bootstrappedUser.role, 'admin');
  assert.equal(bootstrappedUser.email, 'admin@example.test');
  assert.equal(secondBootstrapStatus, 409);
});

test('authenticated users can create, filter, and update persistent issue records', async () => {
  const created = await api('/api/entities/ProductionIssue', {
    method: 'POST',
    cookie: adminCookie,
    body: JSON.stringify({ title: 'Surface defect', issue_type: 'quality', severity: 'high' }),
  });
  assert.equal(created.status, 201);
  const issue = await created.json();
  assert.equal(issue.created_by, 'admin@example.test');

  const filtered = await api(`/api/entities/ProductionIssue?filter=${encodeURIComponent(JSON.stringify({ severity: 'high' }))}`, {
    cookie: adminCookie,
  });
  assert.equal(filtered.status, 200);
  assert.equal((await filtered.json()).length, 1);

  const updated = await api(`/api/entities/ProductionIssue/${issue.id}`, {
    method: 'PATCH',
    cookie: adminCookie,
    body: JSON.stringify({ status: 'closed' }),
  });
  assert.equal(updated.status, 200);
  assert.equal((await updated.json()).status, 'closed');

  const adminIssue = await api('/api/entities/ProductionIssue', {
    method: 'POST',
    cookie: adminCookie,
    body: JSON.stringify({ title: 'Protected issue', issue_type: 'quality' }),
  });
  const protectedIssue = await adminIssue.json();
  const deniedUpdate = await api(`/api/entities/ProductionIssue/${protectedIssue.id}`, {
    method: 'PATCH',
    cookie: userCookie,
    body: JSON.stringify({ status: 'open' }),
  });
  assert.equal(deniedUpdate.status, 403);
});

test('administrators can create accounts and user permissions are enforced', async () => {
  assert.equal(createdOperator.role, 'user');
  assert.equal(userLoginStatus, 200);

  const users = await api('/api/functions/getUsers', {
    method: 'POST',
    cookie: userCookie,
    body: JSON.stringify({}),
  });
  assert.equal(users.status, 200);
  assert.equal((await users.json()).full.length, 2);

  const deniedDelete = await api('/api/entities/ProductionIssue/not-a-real-record', {
    method: 'DELETE',
    cookie: userCookie,
  });
  assert.equal(deniedDelete.status, 403);
});

test('anonymous requests cannot read private application data', async () => {
  const response = await api('/api/entities/ProductionIssue');
  assert.equal(response.status, 401);
});

test('corrective-action owners can submit feedback without editing issue fields', async () => {
  const created = await api('/api/entities/ProductionIssue', {
    method: 'POST',
    cookie: adminCookie,
    body: JSON.stringify({
      title: 'Owner feedback test',
      issue_type: 'quality',
      corrective_actions_json: JSON.stringify([{ owner: 'Line Operator', action: 'Inspect part' }]),
    }),
  });
  const issue = await created.json();
  const response = await api('/api/functions/saveOwnerFeedback', {
    method: 'POST',
    cookie: userCookie,
    body: JSON.stringify({
      issue_id: issue.id,
      actions: [{ owner_feedback: 'Inspection completed', feedback_date: '2026-10-25' }],
    }),
  });
  assert.equal(response.status, 200);
  const result = await response.json();
  assert.equal(result.success, true);
  assert.equal(JSON.parse(result.corrective_actions_json)[0].owner_feedback, 'Inspection completed');
});

test('uploads are available to the app and provider failures are explicit', async () => {
  const upload = await api('/api/integrations/upload', {
    method: 'POST',
    cookie: adminCookie,
    body: JSON.stringify({
      file_name: 'photo.png',
      file_type: 'image/png',
      file_data: 'data:image/png;base64,iVBORw0KGgo=',
    }),
  });
  assert.equal(upload.status, 201);
  const { file_url } = await upload.json();
  assert.equal((await fetch(`${baseUrl}${file_url}`)).status, 200);

  const email = await api('/api/functions/sendEmail', {
    method: 'POST',
    cookie: adminCookie,
    body: JSON.stringify({ to: 'user@example.test', subject: 'Test', body: 'Test' }),
  });
  assert.equal(email.status, 503);
});

test('production server serves the built frontend entry point', async () => {
  const response = await fetch(`${baseUrl}/`);
  assert.equal(response.status, 200);
  assert.match(await response.text(), /RCCA Tracker \| Aeronamic Sibiu/);
});

test('sign-in requests are rate-limited after repeated failures', async () => {
  for (let attempt = 0; attempt < 10; attempt += 1) {
    const response = await api('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email: 'admin@example.test', password: 'incorrect-password' }),
    });
    assert.equal(response.status, 401);
  }
  const limited = await api('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email: 'admin@example.test', password: 'test-admin-password-1' }),
  });
  assert.equal(limited.status, 429);
});
