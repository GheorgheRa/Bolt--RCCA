import assert from 'node:assert/strict';
import { test } from 'node:test';
import {
  USER_EXPORT_HEADERS,
  buildUserExportRows,
  formatPageAccess,
  parsePageAccess,
  rowsToNewUsers,
} from '../src/components/settings/usersFiles.js';

test('creates new users from any column order and skips existing, repeated and invalid emails', () => {
  const existing = [{ email: 'admin@example.com' }];
  const table = [
    ['Rol', 'Email', 'Nume', 'Parola'],
    ['admin', 'Ion.Popescu@Example.com', 'Ion Popescu', 'a-long-password-123'],
    ['user', 'ADMIN@example.com', 'Dup', ''],
    ['', 'ion.popescu@example.com', 'Again', ''],
    ['', 'not-an-email', 'Bad', ''],
    ['', 'maria@example.com', '', 'short'],
  ];
  const result = rowsToNewUsers(table, existing);
  assert.equal(result.duplicates, 2);
  assert.equal(result.invalid, 1);
  assert.equal(result.generatedPasswords, 1);
  assert.deepEqual(result.toCreate.map(u => [u.email, u.full_name, u.role, u.generated]), [
    ['ion.popescu@example.com', 'Ion Popescu', 'admin', false],
    ['maria@example.com', 'maria', 'user', true],
  ]);
  assert.equal(result.toCreate[0].password, 'a-long-password-123');
  assert.ok(result.toCreate[1].password.length >= 12);
});

test('requires a header row with an email column', () => {
  const result = rowsToNewUsers([['ion@example.com', 'Ion']], []);
  assert.equal(result.headerDetected, false);
  assert.equal(result.toCreate.length, 0);
});

test('page access round-trips between export text and stored permissions', () => {
  assert.equal(formatPageAccess(null, 'admin'), 'All');
  assert.equal(formatPageAccess(null, 'user'), 'Dashboard, Issues');
  const parsed = parsePageAccess('Issues; Production Monitor, settings, Foo');
  assert.deepEqual(parsed.unknown, ['foo']);
  const permissions = JSON.parse(parsed.value);
  assert.equal(permissions.Issues, true);
  assert.equal(permissions.BatchMonitor, true);
  assert.equal(permissions.Dashboard, false);
  assert.equal(formatPageAccess(parsed.value), 'Issues, Production Monitor, Settings');
  assert.equal(parsePageAccess('').value, null);
  assert.ok(Object.values(JSON.parse(parsePageAccess('All').value)).every(Boolean));
  assert.equal(formatPageAccess(parsePageAccess('None').value), 'None');
});

test('exported users can be imported back into an empty installation without passwords', () => {
  const users = [{
    email: 'b@example.com', full_name: 'B User', display_name: 'Bee', role: 'user',
    page_permissions: JSON.stringify({ Issues: true }), created_date: '2026-01-02T10:00:00Z',
  }];
  const table = [USER_EXPORT_HEADERS, ...buildUserExportRows(users)];
  assert.deepEqual(table[1], ['B User', 'Bee', 'b@example.com', 'user', 'Issues', '2026-01-02']);
  const [created] = rowsToNewUsers(table, []).toCreate;
  assert.equal(created.display_name, 'Bee');
  assert.equal(created.role, 'user');
  assert.equal(JSON.parse(created.page_permissions).Issues, true);
  assert.equal(created.generated, true);
});
